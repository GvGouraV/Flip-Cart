const empData = [
    {id:1,name:"Gourav",company:"MilestoneOs",age:"22"},
    {id:2,name:"Partik",company:"MC PvtLtd",age:"21"},
    {id:3,name:"Rohit",company:"MilestoneOs",age:"32"},
    {id:4,name:"Mohit",company:"Wipro",age:"12"},
    {id:5,name:"Partik",company:"MC PvtLtd",age:"21"},
    {id:6,name:"Rohit",company:"MilestoneOs",age:"32"},
] 
module.exports.EmpData = empData